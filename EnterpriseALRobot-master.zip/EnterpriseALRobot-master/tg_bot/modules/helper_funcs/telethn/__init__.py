from tg_bot import (
    telethn,
    SUDO_USERS,
    WHITELIST_USERS,
    SUPPORT_USERS,
    SARDEGNA_USERS,
    DEV_USERS,
)

HIGHER_AUTH = SUDO_USERS + DEV_USERS

HIGHER_AUTH = list(SUDO_USERS) + list(DEV_USERS)

HIGHER_AUTH.append(1087968824)
